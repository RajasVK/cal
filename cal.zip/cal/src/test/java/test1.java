import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

//import java.util.List;

public class test1
{
    WebDriver driver;

    @BeforeTest
    void initialize()
    {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.get("https://www.calculator.net/bmi-calculator.html");
        driver.manage().window().maximize();
    }

    @AfterTest
    public void Close_driver()
    {
        driver.close();
    }


    String calculate1(String a, String b, String c)
    {
        WebElement abc = driver.findElement(By.className("clearbtn"));
        abc.click();
        driver.findElement(By.id("cage")).sendKeys(a);

        driver.findElement(By.name("cheightmeter")).sendKeys(b);
        driver.findElement(By.name("ckg")).sendKeys(c);
        driver.findElement(By.xpath("//input[@type='image']")).click();
        String  actual = driver.findElement(By.tagName("b")).getText().trim();
        return actual;

    }
    @Test(priority = 1)
    void testcase1()
    {
        driver.findElement(By.className("rbmark")).click();
        Assert.assertEquals(calculate1("20","180","60"),"BMI = 18.5 kg/m2");
    }
    @Test(priority = 2)
    void testcase2()
    {
        driver.findElement(By.xpath("//tbody/tr[2]/td[2]/label[2]")).click();
        Assert.assertEquals(calculate1("35","160","55"),"BMI = 21.5 kg/m2");
    }
    @Test(priority = 3)
    void testcase3()
    {
        driver.findElement(By.className("rbmark")).click();
        Assert.assertEquals(calculate1("50","175","65"),"BMI = 21.2 kg/m2");

    }
    @Test(priority = 4)
    void testcase4()
    {
        driver.findElement(By.xpath("//tbody/tr[2]/td[2]/label[2]")).click();
        Assert.assertEquals(calculate1("45","150","52"),"BMI = 23.1 kg/m2");
    }
}














